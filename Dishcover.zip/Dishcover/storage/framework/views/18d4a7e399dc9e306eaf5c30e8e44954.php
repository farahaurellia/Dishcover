<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/search.css')); ?>">
    <?php $__env->stopPush(); ?> 
    <div class="search-page">
    <div class="title">
        <a href="/" class="back-btn">
            <svg width="20" height="40" viewBox="0 0 20 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M5.57167 20.0001L17.3567 31.7851L15 34.1417L2.03667 21.1784C1.72422 20.8659 1.54869 20.442 1.54869 20.0001C1.54869 19.5581 1.72422 19.1343 2.03667 18.8217L15 5.8584L17.3567 8.21506L5.57167 20.0001Z" fill="black"/>
            </svg>
        </a>  
        <div class="title-text">
            <p> Hasil untuk <span><?php echo e($query); ?></span></p>
        </div>  
    </div>
    <?php if($recipes->isEmpty()): ?>
    <div class="not-found">
        <p>Resep tidak ditemukan</p>
    </div>
    <?php else: ?> 
    <div class="recipes">
        <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('show', $recipe->id)); ?>" class="recipe-card-link">
                    <div class="recipe-card">
                        <div class="image-wrapper">                        
                            <img src="<?php echo e(asset($recipe->image_url)); ?>" alt="Recipe Image">
                        </div>                          
                        <div class="recipe-info">
                            <div class="tags">
                                <span class="porsi">
                                    <img src="<?php echo e(asset('icons/porsi.svg')); ?>" alt="porsi">                            
                                    <?php echo e($recipe->porsi); ?>

                                </span>
                                <span class="waktu">
                                    <img src="<?php echo e(asset('icons/waktu.svg')); ?>" alt="waktu">                                                        
                                    <?php echo e($recipe->waktu); ?> minutes
                                </span>
                            </div>
                            <h5><?php echo e($recipe->judul); ?></h5>
                            <p><?php echo e($recipe->deskripsi); ?></p>
                            <p>Recipe by <span style="color: #E35778"> <?php echo e($recipe->user->username); ?> </span></p>
                        </div>
                    </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\Users\Dell.RIKCY\Herd\Dishcover\Dishcover\resources\views/search.blade.php ENDPATH**/ ?>