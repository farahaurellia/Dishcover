<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/contentresep.css')); ?>">
    <?php $__env->stopPush(); ?> 
            <div id="carouselExampleIndicators" class="carousel slide">
                <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
                </div>
                <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="<?php echo e(asset('images/carousel1.png')); ?>" alt="carousel">                
                </div>
                <div class="carousel-item">
                    <img src="<?php echo e(asset('images/carousel2.png')); ?>" alt="carousel">                
                </div>
                <div class="carousel-item">
                    <img src="<?php echo e(asset('images/carousel3.png')); ?>" class="d-block" alt="...">
                </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
                </button>
            </div>

            <div class="recommendations">
                <div class="section-title">
                    <p> Mungkin anda suka </p>
                </div>
                <div class="recipes">
                    <?php $__currentLoopData = $recommendations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommendation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('show', $recommendation->id)); ?>" class="recipe-card-link">
                        <div class="recipe-card">
                            <div class="image-wrapper">                        
                                <img src="<?php echo e(asset($recommendation->image_url)); ?>" alt="Recipe Image">
                            </div>                          
                            <div class="recipe-info">
                                <div class="tags">
                                    <span class="porsi">
                                        <img src="<?php echo e(asset('icons/porsi.svg')); ?>" alt="porsi">                    
                                        <?php echo e($recommendation->porsi); ?>

                                    </span>
                                    <span class="waktu">
                                        <img src="<?php echo e(asset('icons/waktu.svg')); ?>" alt="waktu">                                                        
                                        <?php echo e($recommendation->waktu); ?> minutes
                                    </span>
                                </div>
                                <h5><?php echo e($recommendation->judul); ?></h5>
                                <p><?php echo e($recommendation->deskripsi); ?></p>
                                <p>Recipe by <span style="color: #E35778"> <?php echo e($recommendation->user->username); ?> </span></p>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="latest">
                <div class="section-title">
                    <p> Terbaru </p>
                </div>
                <div class="recipes">
                    <?php $__currentLoopData = $latestRecipe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('show', $latest->id)); ?>" class="recipe-card-link">
                        <div class="recipe-card">
                            <div class="image-wrapper">                        
                                <img src="<?php echo e(asset($latest->image_url)); ?>" alt="Recipe Image">
                            </div>                          
                            <div class="recipe-info">
                                <div class="tags">
                                    <span class="porsi">
                                        <img src="<?php echo e(asset('icons/porsi.svg')); ?>" alt="porsi">                    
                                        <?php echo e($latest->porsi); ?>

                                    </span>
                                    <span class="waktu">
                                        <img src="<?php echo e(asset('icons/waktu.svg')); ?>" alt="waktu">                                                        
                                        <?php echo e($latest->waktu); ?> minutes
                                    </span>
                                </div>
                                <h5><?php echo e($latest->judul); ?></h5>
                                <p><?php echo e($latest->deskripsi); ?></p>
                                <p>Recipe by <span style="color: #E35778"> <?php echo e($latest->user->username); ?> </span></p>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>


            <div class="reseplain">
                <div class="section-title">
                    <p> Resep lainnya </p>
                </div>
                <div class="recipes">
                    <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('show', $recipe->id)); ?>" class="recipe-card-link">
                        <div class="recipe-card">
                            <div class="image-wrapper">                        
                                <img src="<?php echo e(asset($recipe->image_url)); ?>" alt="Recipe Image">
                            </div>                          
                            <div class="recipe-info">
                                <div class="tags">
                                    <span class="porsi">
                                        <img src="<?php echo e(asset('icons/porsi.svg')); ?>" alt="porsi">                    
                                        <?php echo e($recipe->porsi); ?>

                                    </span>
                                    <span class="waktu">
                                        <img src="<?php echo e(asset('icons/waktu.svg')); ?>" alt="waktu">                                                        
                                        <?php echo e($recipe->waktu); ?> minutes
                                    </span>
                                </div>
                                <h5><?php echo e($recipe->judul); ?></h5>
                                <p><?php echo e($recipe->deskripsi); ?></p>
                                <p>Recipe by <span style="color: #E35778"> <?php echo e($recipe->user->username); ?> </span></p>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="footer">
                <div class="container">
                    <div class="container-top">
                    <div class="signup">
                        <h5 class="brand">
                        <span class="logo">
                            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="logo">
                        </span>
                        <span class="name">DishCover</span>
                        </h5>
                        <p>Stay in the loop and sign up:</p>
                        <form class="email-form">
                        <input type="email" placeholder="Enter your email" required />
                        <button type="submit">&#8594;</button>
                        </form>
                    </div>

                    <div class="links">
                        <div>
                        <span class="name">Company</span>
                        <a href="/">Home</a>
                        </div>
                        <div>
                        <span class="name">Documentation</span>
                        <a href="#">Contact</a>
                        </div>
                        <div>
                        <span class="name">Social</span>
                        <a href="#">Facebook</a>
                        <a href="#">Instagram</a>
                        </div>
                    </div>
                    </div>

                    <div class="container-bottom">
                    <hr />
                    <div class="bottom-content">
                        <p>Made with <span class="heart">&hearts;</span> by DishCover Team</p>
                        <p>Terms & Condition</p>
                    </div>
                    </div>

                </div>
            </div>
        </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\Users\Dell.RIKCY\Herd\Dishcover\Dishcover\resources\views/homepage.blade.php ENDPATH**/ ?>