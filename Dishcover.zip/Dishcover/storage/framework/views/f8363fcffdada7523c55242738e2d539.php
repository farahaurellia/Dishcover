<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('styles'); ?>
            <link rel="stylesheet" href="<?php echo e(asset('css/myrecipe.css')); ?>">
    <?php $__env->stopPush(); ?> 
        <?php if($recipes->isEmpty()): ?>
        <div class="container">
            <div class="content">
                <div class="title">
                    <div class=" recipe-icon">
                        <img src="<?php echo e(asset('icons/myrecipe-p.svg')); ?>" alt="recipe">
                    </div>
                    <h1 class="title-text">Resep Saya</h1>
                </div>
                <div class="message">
                <h2 class="message-text" style="font-size: 16px; font-weight: bold; color: #333;">
                        Halaman masih kosong
                    </h2>
                    <p class="message-subtext" style="font-size: 16px; color: #333;">
                        Ayo unggah resepmu!
                    </p>
                </div>
            </div>
        </div>
        <?php else: ?> 
        <div class="title">
            <div class=" recipe-icon">
                <img src="<?php echo e(asset('icons/myrecipe-p.svg')); ?>" alt="recipe">
                <h1 class="title-text">Resep Saya</h1>
            </div>
        </div>
            <div class="recipes">
            <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('show', $recipe->id)); ?>" class="recipe-card-link">
                <div class="recipe-card">
                    <div class="image-wrapper">                        
                        <img src="<?php echo e(asset($recipe->image_url)); ?>" alt="Recipe Image">
                    </div>                          
                    <div class="recipe-info">
                        <div class="tags">
                            <span class="porsi">
                                <img src="<?php echo e(asset('icons/porsi.svg')); ?>" alt="porsi">                    
                                <?php echo e($recipe->porsi); ?>

                            </span>
                            <span class="waktu">
                                <img src="<?php echo e(asset('icons/waktu.svg')); ?>" alt="waktu">                                                        
                                <?php echo e($recipe->waktu); ?> minutes
                            </span>
                        </div>
                        <h5><?php echo e($recipe->judul); ?></h5>
                        <p><?php echo e($recipe->deskripsi); ?></p>
                        <p>Recipe by <span style="color: #E35778"> <?php echo e($recipe->user->username); ?> </span></p>
                    </div>
                </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH C:\Users\Dell.RIKCY\Herd\Dishcover\Dishcover\resources\views/myrecipe.blade.php ENDPATH**/ ?>