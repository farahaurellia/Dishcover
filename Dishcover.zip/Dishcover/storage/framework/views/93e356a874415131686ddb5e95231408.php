<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?php echo e(asset('css/show.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <div class="container-view">
        <div class="container-content">
        <div class="left-side">
             <a onclick="window.location.href='<?php echo e(url('/')); ?>';" class="back-btn">
                 <svg width="20" height="40" viewBox="0 0 20 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M5.57167 20.0001L17.3567 31.7851L15 34.1417L2.03667 21.1784C1.72422 20.8659 1.54869 20.442 1.54869 20.0001C1.54869 19.5581 1.72422 19.1343 2.03667 18.8217L15 5.8584L17.3567 8.21506L5.57167 20.0001Z" />
                 </svg>
            </a>
                <div class="left-section">
                    <div class="img-wrapper">
                        <img src="<?php echo e(asset($recipe->image_url)); ?>" alt="Recipe Image">
                    </div>
                    <div class="recipe-info">
                        <div class="tags">
                            <div class="tags-left">
                                <span class="porsi">
                                    <img src="<?php echo e(asset('icons/porsi-w.svg')); ?>" alt="porsi">                            
                                    <?php echo e($recipe->porsi); ?>

                                </span>
                                <span class="waktu">
                                    <img src="<?php echo e(asset('icons/waktu-w.svg')); ?>" alt="porsi">                                                       
                                    <?php echo e($recipe->waktu); ?> minutes
                                </span>
                            </div>
                            <div class="tags-right">
                                <?php if(Auth::check()): ?>
                                    <?php if($myrecipe): ?>
                                        <button class="edit-button" id="editButton">
                                            <a href="<?php echo e(route('editPage', $recipe->id)); ?>" >
                                                <img src="<?php echo e(asset('icons/edit.svg')); ?>" alt="edit" style="width: 33px; height: 33px">                                                       
                                            </a>
                                        </button>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <button type="button" class="btn btn-comment" data-bs-toggle="modal" data-bs-target="#commentModal">
                                    <img src="<?php echo e(asset('icons/comment.svg')); ?>" alt="comment" style="width: 30px; height: 30px; margin-top: 2px">                                                       
                                </button>
                                <?php echo csrf_field(); ?>
                                <?php if(Auth::check()): ?>
                                <div class="like-button">
                                    <?php if($likeExists): ?>
                                        <form action="<?php echo e(route('unlike')); ?>" method="POST" style="display: inline">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="recipe_id" value="<?php echo e($recipe->id); ?>">
                                            <button type="submit" class="like-button">
                                                <img src="<?php echo e(asset('icons/liked.svg')); ?>" alt="Unlike" style="width: 30px; height: 30px;">
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <form action="<?php echo e(route('like')); ?>" method="POST" style="display: inline;">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="recipe_id" value="<?php echo e($recipe->id); ?>">
                                            <button type="submit" class="like-button">
                                                <img src="<?php echo e(asset('icons/notliked.svg')); ?>" alt="Like" style="width: 30px; height: 30px;">
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>                           
                                <?php endif; ?>
                                <button class="download-button" id="downloadButton">
                                    <a href="<?php echo e(route('recipes.download', $recipe->id)); ?>" >
                                        <img src="<?php echo e(asset('icons/download.svg')); ?>" alt="download" style="width: 33px; height: 33px">                                                       
                                    </a>
                                </button>
                            </div>
                        </div>
                        <p><?php echo e($recipe->deskripsi); ?></p>
                    </div>
                </div>
            </div>
            <div class="right-side">
                <div class= "container-show">
                    <div class="judul">
                        <h4><?php echo e($recipe->judul); ?></h4>
                        <h6>Recipe by <span style="color: #E35778"> <?php echo e($recipe->user->username); ?> </span></h6>
                    </div>
                <p> Bahan-bahan: </p>
                <ul>
                    <?php $__currentLoopData = $bahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($item); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <p> Langkah-langkah: </p>
                <ol>
                    <?php $__currentLoopData = $langkah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($item); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="commentModal" tabindex="-1" aria-labelledby="commentModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="commentModalLabel">Comments</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="comments align-items-center mb-3">
        <?php if($comments->isEmpty()): ?>
            <div class="d-flex justify-content-center align-items-center" style="height: 70px;">
                <h5>No comments yet.</h5>
            </div>
        <?php else: ?>
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex">
                    <div class="profile-image">
                        <img 
                            src="<?php echo e($comment->profilepicture_url); ?>" 
                            alt="<?php echo e($comment->username); ?>'s profile picture" 
                            class="rounded-circle" 
                            style="width: 50px; height: 50px; object-fit: cover;">
                    </div>
                    <div class="ms-3 mt-2">
                        <div class="username font-weight-bold"><?php echo e($comment->username); ?></div>
                        <div class="user-comment"><?php echo e($comment->isi_komentar); ?></div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?> 
    <?php if(Auth::check()): ?>
        <div class="modal-body">
            <form action="<?php echo e(route('addComment', $recipe->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="commentText" class="form-label" style="color: black;">Your Comment</label>
                    <textarea class="form-control" id="commentText" name="isi_komentar" rows="3" required></textarea>
                </div>
                <button type="submit" class="btn btn-submit" style="background-color: #8DD14F; color: white; border: none; padding: 10px 15px; border-radius: 5px;">Submit</button>
            </form>
        </div>       
    <?php endif; ?>
    </div>
  </div>
</div>
<script>
    document.getElementById('likeButton').addEventListener('click', function() {
        // Toggle kelas 'liked' untuk mengubah warna
        this.classList.toggle('liked');

        // Anda bisa menambahkan aksi ke backend menggunakan fetch() jika diperlukan
        // Contoh:
        // fetch('/like', {
        //     method: 'POST',
        //     body: JSON.stringify({ itemId: 'item-id' }),
        //     headers: {
        //         'Content-Type': 'application/json',
        //     }
        // });
    });
</script>
</body><?php /**PATH C:\Users\Dell.RIKCY\Herd\Dishcover\Dishcover\resources\views/show.blade.php ENDPATH**/ ?>